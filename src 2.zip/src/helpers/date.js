/* eslint-disable import/no-anonymous-default-export */
export default {
    DATE_ES: 'DD-MM-YYYY HH:mm:ss',
    DATE_EN: 'YYYY-MM-DD HH:mm:ss'
};
