import { Modal, Button, Spin, notification } from 'antd';
import { useEffect, useState, useContext } from 'react';
import { LoadingOutlined } from '@ant-design/icons';
import Web3 from 'web3';

import { LargeNumber } from '../../LargeNumber';
import { AuthenticateContext } from '../../../context/Auth';
import { config } from '../../../projects/config';
import { useProjectTranslation } from '../../../helpers/translations';
import './style.scss';

export default function StakingOptionsModal(props) {
    const auth = useContext(AuthenticateContext);
    const { accountData = {} } = auth;
    const {
        mode,
        onClose,
        visible,
        amount,
        onConfirm,
        withdrawalId,
        setBlockedWithdrawals
    } = props;
    const [step, setStep] = useState(0);

    const amountInEth = Web3.utils.fromWei(amount);
    const [t, i18n, ns] = useProjectTranslation();
    const AppProject = config.environment.AppProject;

    useEffect(() => {
        (async () => {
            const allowanceAmount = await auth.interfaceGetMoCAllowance();
            if (allowanceAmount > amount) setStep(2);
        })();
    }, []);
    if (!mode) return null;

    //methods
    const setAllowance = async () => {
        setStep(1);
        await auth
            .interfaceApproveMoCTokenStaking(true, (error) => {})
            .then((res) => {
                setStep(2);
                return null;
            })
            .catch((e) => {
                console.error(e);
                notification['error']({
                    message: 'Operations',
                    description: 'Something went wrong! Transaction rejected!',
                    duration: 10
                });
            });
    };

    const depositMoCs = async () => {
        setStep(99);
        await auth
            .interfaceStakingDeposit(
                amountInEth,
                accountData.Wallet,
                (error, txHash) => {
                    onClose();
                    if (error) {
                        return error;
                    }
                    const status = 'pending';
                    onConfirm(status, txHash);
                }
            )
            .then((res) => {
                const status = res.status ? 'success' : 'error';
                onConfirm(status, res.transactionHash);
                return null;
            })
            .catch((e) => {
                notification['error']({
                    message: t('global.RewardsError_Title'),
                    description: t('global.RewardsError_Message'),
                    duration: 10
                });
            });
    };

    const restakeMoCs = async () => {
        onClose();
        await auth
            .interfaceDelayMachineCancelWithdraw(
                withdrawalId,
                (error, txHash) => {
                    if (error) return error;

                    const status = 'pending';
                    onConfirm(status, txHash);
                    setBlockedWithdrawals((prev) => [...prev, withdrawalId]);
                }
            )
            .then((res) => {
                const status = res.status ? 'success' : 'error';
                onConfirm(status, res.transactionHash);
                setBlockedWithdrawals((prev) =>
                    prev.filter((val) => val !== withdrawMoCs)
                );
                return null;
            })
            .catch((e) => {
                console.error(e);
                notification['error']({
                    message: t('global.RewardsError_Title'),
                    description: t('global.RewardsError_Message'),
                    duration: 10
                });
            });
    };

    const unstakeMoCs = async () => {
        onClose();
        await auth
            .interfaceUnStake(amountInEth, (error, txHash) => {
                if (error) return error;

                const status = 'pending';
                onConfirm(status, txHash);
            })
            .then((res) => {
                const status = res.status ? 'success' : 'error';
                onConfirm(status, res.transactionHash);
                return null;
            })
            .catch((e) => {
                console.error(e);
                notification['error']({
                    message: t('global.RewardsError_Title'),
                    description: t('global.RewardsError_Message'),
                    duration: 10
                });
            });
    };
    const withdrawMoCs = () => {
        onClose();
        auth.interfaceDelayMachineWithdraw(withdrawalId, (error, txHash) => {
            if (error) return error;

            const status = 'pending';
            onConfirm(status, txHash);
            setBlockedWithdrawals((prev) => [...prev, withdrawalId]);
        })
            .then((res) => {
                const status = res.status ? 'success' : 'error';
                onConfirm(status, res.transactionHash);
                setBlockedWithdrawals((prev) =>
                    prev.filter((val) => val !== withdrawMoCs)
                );
                return null;
            })
            .catch((e) => {
                console.error(e);
                notification['error']({
                    message: t('global.RewardsError_Title'),
                    description: t('global.RewardsError_Message'),
                    duration: 10
                });
            });
    };

    // renders
    const renderStaking = () => {
        const steps = {
            0: () => {
                return (
                    <>
                        <h1 className="StakingOptionsModal_Title">
                            {t('global.StakingOptionsModal_SetAllowance')}
                        </h1>
                        <div className="StakingOptionsModal_Content">
                            <p>
                                {t(
                                    'global.StakingOptionsModal_AllowanceDescription'
                                )}
                            </p>
                            <div
                                style={{
                                    display: 'flex',
                                    justifyContent: 'center'
                                }}
                            >
                                <Button type="primary" onClick={setAllowance}>
                                    {t('global.StakingOptionsModal_Authorize')}
                                </Button>
                            </div>
                        </div>
                    </>
                );
            },
            1: () => {
                return (
                    <>
                        <h1 className="StakingOptionsModal_Title">
                            {t('global.StakingOptionsModal_SetAllowance')}
                        </h1>
                        <div className="StakingOptionsModal_Content AllowanceLoading">
                            <Spin indicator={<LoadingOutlined />} />
                            <p>
                                {t(
                                    'global.StakingOptionsModal_ProccessingAllowance'
                                )}
                            </p>
                        </div>
                    </>
                );
            },
            2: () => {
                return (
                    <>
                        <h1 className="StakingOptionsModal_Title">
                            {t('global.StakingOptionsModal_Title')}
                        </h1>
                        <div className="StakingOptionsModal_Content">
                            <div className="InfoContainer">
                                <span className="title">
                                    {t(
                                        'global.StakingOptionsModal_AmountToStake'
                                    )}
                                </span>
                                <span className="value amount">
                                    <LargeNumber
                                        amount={amount}
                                        currencyCode="RESERVE"
                                    />{' '}
                                    <span>
                                        {t(`${AppProject}.Tokens_TG_code`, {
                                            ns: ns
                                        })}
                                    </span>
                                </span>
                            </div>
                            <p>
                                {t(
                                    'global.StakingOptionsModal_StakingDescription'
                                )}
                            </p>
                            <div className="ActionButtonsRow">
                                <Button type="default" onClick={onClose}>
                                    {t('global.StakingOptionsModal_Cancel')}
                                </Button>
                                <Button
                                    type="primary"
                                    onClick={depositMoCs}
                                    className="ButtonPrimary"
                                >
                                    {t('global.StakingOptionsModal_Comfirm')}
                                </Button>
                            </div>
                        </div>
                    </>
                );
            },
            99: () => {
                return (
                    <>
                        <h1 className="StakingOptionsModal_Title">
                            {t('global.StakingOptionsModal_ReviewYourWallet')}
                        </h1>
                        <div className="StakingOptionsModal_Content AllowanceLoading">
                            <Spin indicator={<LoadingOutlined />} />
                            <p>
                                {t(
                                    'global.StakingOptionsModal_ReviewYourWalletDescription'
                                )}
                            </p>
                        </div>
                    </>
                );
            }
        };

        return steps[step] ? steps[step]() : null;
    };

    const renderUnstaking = () => {
        return (
            <>
                <h1 className="StakingOptionsModal_Title">
                    {t('global.StakingOptionsModal_UnstakeTitle')}
                </h1>
                <div className="StakingOptionsModal_Content">
                    <div className="InfoContainer">
                        <span className="title">
                            {t('global.StakingOptionsModal_AmountToUnstake')}
                        </span>
                        <span className="value amount">
                            <LargeNumber
                                amount={amount}
                                currencyCode="RESERVE"
                            />{' '}
                            <span>
                                {t(`${AppProject}.Tokens_TG_code`, { ns: ns })}
                            </span>
                        </span>
                    </div>
                    <p>
                        {t('global.StakingOptionsModal_UnstakingDescription')}
                    </p>
                    <div className="ActionButtonsRow">
                        <Button type="default" onClick={onClose}>
                            {t('global.StakingOptionsModal_Cancel')}
                        </Button>
                        <Button
                            type="primary"
                            onClick={unstakeMoCs}
                            className="ButtonPrimary"
                        >
                            {t('global.StakingOptionsModal_Comfirm')}
                        </Button>
                    </div>
                </div>
            </>
        );
    };

    const renderWithdraw = () => {
        return (
            <>
                <h1 className="StakingOptionsModal_Title">
                    {t('global.StakingOptionsModal_WithdrawTitle')}
                </h1>
                <div className="StakingOptionsModal_Content">
                    <div className="InfoContainer">
                        <span className="title">
                            {t('global.StakingOptionsModal_AmountToWithdraw')}
                        </span>
                        <span className="value amount">
                            <LargeNumber
                                amount={amount}
                                currencyCode="RESERVE"
                            />{' '}
                            <span>
                                {t(`${AppProject}.Tokens_TG_code`, { ns: ns })}
                            </span>
                        </span>
                    </div>
                    <p>{t('global.StakingOptionsModal_WithdrawDescription')}</p>
                    <div className="ActionButtonsRow">
                        <Button type="default" onClick={onClose}>
                            {t('global.StakingOptionsModal_Cancel')}
                        </Button>
                        <Button
                            type="primary"
                            onClick={withdrawMoCs}
                            className="ButtonPrimary"
                        >
                            {t('global.StakingOptionsModal_Comfirm')}
                        </Button>
                    </div>
                </div>
            </>
        );
    };

    const renderRestaking = () => {
        return (
            <>
                <h1 className="StakingOptionsModal_Title">
                    {t('global.StakingOptionsModal_RestakeTitle')}
                </h1>
                <div className="StakingOptionsModal_Content">
                    <div className="InfoContainer">
                        <span className="title">
                            {t('global.StakingOptionsModal_AmountToRestake')}
                        </span>
                        <span className="value amount">
                            <LargeNumber
                                amount={amount}
                                currencyCode="RESERVE"
                            />{' '}
                            <span>
                                {t(`${AppProject}.Tokens_TG_code`, { ns: ns })}
                            </span>
                        </span>
                    </div>
                    <p>{t('global.StakingOptionsModal_RestakeDescription')}</p>
                    <div className="ActionButtonsRow">
                        <Button type="default" onClick={onClose}>
                            {t('global.StakingOptionsModal_Cancel')}
                        </Button>
                        <Button
                            type="primary"
                            onClick={restakeMoCs}
                            className="ButtonPrimary"
                        >
                            {t('global.StakingOptionsModal_Comfirm')}
                        </Button>
                    </div>
                </div>
            </>
        );
    };

    const render = () => {
        const modes = {
            staking: renderStaking,
            unstaking: renderUnstaking,
            withdraw: renderWithdraw,
            restake: renderRestaking
        };

        return modes[mode]();
    };

    return (
        <Modal
            className="StakingOptionsModal"
            visible={visible}
            onCancel={onClose}
            footer={null}
        >
            {render()}
        </Modal>
    );
}
